<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing includes...<br>";

try {
    require_once 'config.php';
    echo "✅ config.php loaded<br>";
    
    require_once 'core/Database.php';
    echo "✅ Database.php loaded<br>";
    
    $db = Database::getInstance();
    echo "✅ Database instance created<br>";
    
    $connection = $db->getConnection();
    echo "✅ Database connection established<br>";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
    echo "Stack trace: <pre>" . $e->getTraceAsString() . "</pre>";
}
?>
