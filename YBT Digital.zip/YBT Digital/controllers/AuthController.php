<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/User.php';

class AuthController extends Controller {
    private $userModel;
    
    public function __construct() {
        parent::__construct();
        $this->userModel = new User();
    }
    
    public function login() {
        if ($this->isPost()) {
            $email = $this->getPost('email');
            $password = $this->getPost('password');
            $remember = $this->getPost('remember');
            
            // Validation
            $errors = [];
            if (empty($email)) $errors['email'] = 'Email is required';
            if (empty($password)) $errors['password'] = 'Password is required';
            if (!$this->validateEmail($email)) $errors['email'] = 'Invalid email format';
            
            if (empty($errors)) {
                try {
                    $user = $this->userModel->authenticate($email, $password);
                    
                    if ($user) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_name'] = $user['name'];
                        $_SESSION['user_email'] = $user['email'];
                        
                        if ($remember) {
                            setcookie('remember_email', $email, time() + (30 * 24 * 60 * 60), '/');
                        }
                        
                        flashMessage('success', 'Welcome back, ' . $user['name'] . '!');
                        
                        $redirect = $_SESSION['redirect_after_login'] ?? '';
                        unset($_SESSION['redirect_after_login']);
                        redirect($redirect ?: 'orders');
                        
                    } else {
                        $errors['login'] = 'Invalid email or password';
                    }
                } catch (Exception $e) {
                    $errors['login'] = 'Login failed. Please try again.';
                }
            }
            
            if (!empty($errors)) {
                flashMessage('error', reset($errors));
            }
        }
        
        $this->render('auth/login', [
            'title' => 'Login - ' . SITE_NAME,
            'errors' => $errors ?? []
        ]);
    }
    
    public function signup() {
        if ($this->isPost()) {
            $name = $this->getPost('name');
            $email = $this->getPost('email');
            $password = $this->getPost('password');
            $confirmPassword = $this->getPost('confirm_password');
            $phone = $this->getPost('phone');
            $terms = $this->getPost('terms');
            
            // Validation
            $errors = [];
            if (empty($name)) $errors['name'] = 'Name is required';
            if (empty($email)) $errors['email'] = 'Email is required';
            if (!$this->validateEmail($email)) $errors['email'] = 'Invalid email format';
            if (empty($password)) $errors['password'] = 'Password is required';
            if (!$this->validatePassword($password)) $errors['password'] = 'Password must be at least 8 characters';
            if ($password !== $confirmPassword) $errors['confirm_password'] = 'Passwords do not match';
            if (!$terms) $errors['terms'] = 'You must agree to the terms and conditions';
            
            if (empty($errors)) {
                try {
                    $userData = [
                        'name' => $name,
                        'email' => $email,
                        'password_hash' => password_hash($password, PASSWORD_BCRYPT),
                        'phone' => $phone,
                        'verification_token' => generateToken()
                    ];
                    
                    $userId = $this->userModel->create($userData);
                    
                    // Send verification email
                    $this->sendVerificationEmail($email, $userData['verification_token']);
                    
                    flashMessage('success', 'Account created successfully! Please check your email to verify your account.');
                    redirect('auth/login');
                    
                } catch (Exception $e) {
                    if (strpos($e->getMessage(), 'Email already exists') !== false) {
                        $errors['email'] = 'Email already exists';
                    } else {
                        $errors['general'] = 'Registration failed. Please try again.';
                    }
                }
            }
            
            if (!empty($errors)) {
                flashMessage('error', reset($errors));
            }
        }
        
        $this->render('auth/signup', [
            'title' => 'Sign Up - ' . SITE_NAME,
            'errors' => $errors ?? []
        ]);
    }
    
    public function logout() {
        session_destroy();
        setcookie('remember_email', '', time() - 3600, '/');
        flashMessage('success', 'You have been logged out successfully.');
        redirect('');
    }
    
    public function forgot() {
        if ($this->isPost()) {
            $email = $this->getPost('email');
            
            $errors = [];
            if (empty($email)) $errors['email'] = 'Email is required';
            if (!$this->validateEmail($email)) $errors['email'] = 'Invalid email format';
            
            if (empty($errors)) {
                $user = $this->userModel->findByEmail($email);
                
                if ($user) {
                    $token = generateToken();
                    $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
                    
                    $this->userModel->setResetToken($user['id'], $token, $expiry);
                    $this->sendPasswordResetEmail($email, $token);
                }
                
                // Always show success message to prevent email enumeration
                flashMessage('success', 'If an account with that email exists, a password reset link has been sent.');
                redirect('auth/login');
            } else {
                flashMessage('error', reset($errors));
            }
        }
        
        $this->render('auth/forgot', [
            'title' => 'Forgot Password - ' . SITE_NAME,
            'errors' => $errors ?? []
        ]);
    }
    
    public function reset() {
        $token = $this->getQuery('token');
        
        if (!$token) {
            flashMessage('error', 'Invalid reset token.');
            redirect('auth/forgot');
        }
        
        $user = $this->userModel->findByResetToken($token);
        
        if (!$user) {
            flashMessage('error', 'Invalid or expired reset token.');
            redirect('auth/forgot');
        }
        
        if ($this->isPost()) {
            $password = $this->getPost('password');
            $confirmPassword = $this->getPost('confirm_password');
            
            $errors = [];
            if (empty($password)) $errors['password'] = 'Password is required';
            if (!$this->validatePassword($password)) $errors['password'] = 'Password must be at least 8 characters';
            if ($password !== $confirmPassword) $errors['confirm_password'] = 'Passwords do not match';
            
            if (empty($errors)) {
                try {
                    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
                    $this->userModel->resetPassword($user['id'], $passwordHash);
                    
                    flashMessage('success', 'Password reset successfully! You can now login with your new password.');
                    redirect('auth/login');
                    
                } catch (Exception $e) {
                    $errors['general'] = 'Password reset failed. Please try again.';
                }
            }
            
            if (!empty($errors)) {
                flashMessage('error', reset($errors));
            }
        }
        
        $this->render('auth/reset', [
            'title' => 'Reset Password - ' . SITE_NAME,
            'token' => $token,
            'errors' => $errors ?? []
        ]);
    }
    
    public function verify() {
        $token = $this->getQuery('token');
        
        if (!$token) {
            flashMessage('error', 'Invalid verification token.');
            redirect('');
        }
        
        $user = $this->userModel->findByVerificationToken($token);
        
        if (!$user) {
            flashMessage('error', 'Invalid or expired verification token.');
            redirect('');
        }
        
        try {
            $this->userModel->verifyEmail($user['id']);
            flashMessage('success', 'Email verified successfully! You can now login.');
            redirect('auth/login');
        } catch (Exception $e) {
            flashMessage('error', 'Email verification failed. Please try again.');
            redirect('');
        }
    }
    
    public function profile() {
        $this->requireAuth();
        
        $user = getCurrentUser();
        
        if ($this->isPost()) {
            $name = $this->getPost('name');
            $email = $this->getPost('email');
            $phone = $this->getPost('phone');
            $currentPassword = $this->getPost('current_password');
            $newPassword = $this->getPost('new_password');
            $confirmPassword = $this->getPost('confirm_password');
            
            $errors = [];
            if (empty($name)) $errors['name'] = 'Name is required';
            if (empty($email)) $errors['email'] = 'Email is required';
            if (!$this->validateEmail($email)) $errors['email'] = 'Invalid email format';
            
            // Check if email is being changed and if it's already taken
            if ($email !== $user['email']) {
                $existingUser = $this->userModel->findByEmail($email);
                if ($existingUser) {
                    $errors['email'] = 'Email already exists';
                }
            }
            
            // Password change validation
            if (!empty($newPassword)) {
                if (empty($currentPassword)) {
                    $errors['current_password'] = 'Current password is required';
                } elseif (!password_verify($currentPassword, $user['password_hash'])) {
                    $errors['current_password'] = 'Current password is incorrect';
                } elseif (!$this->validatePassword($newPassword)) {
                    $errors['new_password'] = 'New password must be at least 8 characters';
                } elseif ($newPassword !== $confirmPassword) {
                    $errors['confirm_password'] = 'Passwords do not match';
                }
            }
            
            if (empty($errors)) {
                try {
                    $updateData = [
                        'name' => $name,
                        'email' => $email,
                        'phone' => $phone
                    ];
                    
                    if (!empty($newPassword)) {
                        $updateData['password_hash'] = password_hash($newPassword, PASSWORD_BCRYPT);
                    }
                    
                    $this->userModel->update($user['id'], $updateData);
                    
                    // Update session
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    
                    flashMessage('success', 'Profile updated successfully!');
                    redirect('auth/profile');
                    
                } catch (Exception $e) {
                    $errors['general'] = 'Profile update failed. Please try again.';
                }
            }
            
            if (!empty($errors)) {
                flashMessage('error', reset($errors));
            }
        }
        
        $this->render('auth/profile', [
            'title' => 'My Profile - ' . SITE_NAME,
            'user' => $user,
            'errors' => $errors ?? []
        ]);
    }
    
    private function sendVerificationEmail($email, $token) {
        $subject = 'Verify Your Email - ' . SITE_NAME;
        $verificationUrl = SITE_URL . 'index.php?page=auth&action=verify&token=' . $token;
        
        $message = "
            <h2>Email Verification</h2>
            <p>Thank you for registering with " . SITE_NAME . "!</p>
            <p>Please click the link below to verify your email address:</p>
            <p><a href='{$verificationUrl}'>Verify Email</a></p>
            <p>If you didn't create an account, you can safely ignore this email.</p>
            <p>This link will expire in 24 hours.</p>
        ";
        
        return sendEmail($email, $subject, $message);
    }
    
    private function sendPasswordResetEmail($email, $token) {
        $subject = 'Password Reset - ' . SITE_NAME;
        $resetUrl = SITE_URL . 'index.php?page=auth&action=reset&token=' . $token;
        
        $message = "
            <h2>Password Reset</h2>
            <p>You requested a password reset for your account at " . SITE_NAME . ".</p>
            <p>Click the link below to reset your password:</p>
            <p><a href='{$resetUrl}'>Reset Password</a></p>
            <p>If you didn't request this reset, you can safely ignore this email.</p>
            <p>This link will expire in 1 hour.</p>
        ";
        
        return sendEmail($email, $subject, $message);
    }
}
?>
