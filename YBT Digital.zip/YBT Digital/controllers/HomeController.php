<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

class HomeController extends Controller {
    private $productModel;
    private $categoryModel;
    
    public function __construct() {
        parent::__construct();
        $this->productModel = new Product();
        $this->categoryModel = new Category();
    }
    
    public function index() {
        // Get featured products
        $featuredProducts = $this->productModel->getFeatured(8);
        
        // Get latest products
        $latestProducts = $this->productModel->getLatestProducts(8);
        
        // Get popular products
        $popularProducts = $this->productModel->getPopularProducts(8);
        
        // Get categories
        $categories = $this->categoryModel->getAllActive();
        
        // Get testimonials
        $testimonials = $this->getTestimonials();
        
        $this->render('home', [
            'title' => 'Welcome to ' . SITE_NAME,
            'description' => 'Discover amazing digital products at ' . SITE_NAME,
            'hero' => [
                'title' => 'Discover Premium Digital Products',
                'subtitle' => 'Software, Templates, Courses, and More - All in One Place',
                'cta' => 'Explore Products',
                'cta_url' => SITE_URL . 'index.php?page=products'
            ],
            'featuredProducts' => $featuredProducts,
            'latestProducts' => $latestProducts,
            'popularProducts' => $popularProducts,
            'categories' => $categories,
            'testimonials' => $testimonials
        ]);
    }
    
    private function getTestimonials() {
        // In a real application, this would come from the database
        return [
            [
                'name' => 'Sarah Johnson',
                'role' => 'Web Developer',
                'content' => 'Amazing platform! Found exactly what I needed for my projects. The quality is outstanding.',
                'rating' => 5,
                'avatar' => 'assets/images/avatars/user1.jpg'
            ],
            [
                'name' => 'Mike Chen',
                'role' => 'Designer',
                'content' => 'The templates here are top-notch. Saved me hours of work and my clients love the results.',
                'rating' => 5,
                'avatar' => 'assets/images/avatars/user2.jpg'
            ],
            [
                'name' => 'Emily Davis',
                'role' => 'Entrepreneur',
                'content' => 'Great selection of digital products. Easy to purchase and download. Highly recommended!',
                'rating' => 5,
                'avatar' => 'assets/images/avatars/user3.jpg'
            ]
        ];
    }
    
    protected function getCategoryIcon($slug) {
        $icons = [
            'software' => 'fas fa-desktop',
            'templates' => 'fas fa-file-code',
            'courses' => 'fas fa-graduation-cap',
            'ebooks' => 'fas fa-book',
            'graphics' => 'fas fa-palette',
            'audio' => 'fas fa-music',
            'video' => 'fas fa-video',
            'plugins' => 'fas fa-plug'
        ];
        
        return $icons[$slug] ?? 'fas fa-folder';
    }
}
?>
