<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

class ProductController extends Controller {
    private $productModel;
    private $categoryModel;
    
    public function __construct() {
        parent::__construct();
        $this->productModel = new Product();
        $this->categoryModel = new Category();
    }
    
    public function listing() {
        $search = $this->getQuery('search');
        $category = $this->getQuery('category');
        $minPrice = $this->getQuery('min_price');
        $maxPrice = $this->getQuery('max_price');
        $sortBy = $this->getQuery('sort', 'created_at');
        $sortOrder = $this->getQuery('order', 'DESC');
        $page = max(1, (int)$this->getQuery('page', 1));
        
        // Parse category from slug to ID
        $categoryId = null;
        if ($category) {
            $categoryData = $this->categoryModel->findBySlug($category);
            $categoryId = $categoryData ? $categoryData['id'] : null;
        }
        
        // Get products with pagination
        $offset = ($page - 1) * ITEMS_PER_PAGE;
        $products = $this->productModel->search(
            $search,
            $categoryId,
            $minPrice,
            $maxPrice,
            $sortBy,
            $sortOrder,
            ITEMS_PER_PAGE,
            $offset
        );
        
        $totalProducts = $this->productModel->countSearch($search, $categoryId, $minPrice, $maxPrice);
        $totalPages = ceil($totalProducts / ITEMS_PER_PAGE);
        
        // Get categories for filter
        $categories = $this->categoryModel->getAllActive();
        
        // Get price range
        $priceRange = $this->productModel->getPriceRange();
        
        $this->render('products/listing', [
            'title' => 'Products - ' . SITE_NAME,
            'description' => 'Browse our collection of premium digital products',
            'products' => $products,
            'categories' => $categories,
            'priceRange' => $priceRange,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_items' => $totalProducts,
                'per_page' => ITEMS_PER_PAGE,
                'has_next' => $page < $totalPages,
                'has_prev' => $page > 1
            ],
            'filters' => [
                'search' => $search,
                'category' => $category,
                'min_price' => $minPrice,
                'max_price' => $maxPrice,
                'sort' => $sortBy,
                'order' => $sortOrder
            ]
        ]);
    }
    
    public function detail($id) {
        if (!$id) {
            $this->json(['error' => 'Product ID required'], 400);
            return;
        }
        
        $product = $this->productModel->findById($id);
        
        if (!$product || $product['status'] !== 'active') {
            $this->render('errors/404', ['title' => 'Product Not Found']);
            return;
        }
        
        // Get related products
        $relatedProducts = $this->productModel->getRelatedProducts(
            $product['id'],
            $product['category_id'],
            4
        );
        
        // Parse screenshots
        $screenshots = json_decode($product['screenshots'] ?? '[]', true);
        
        $this->render('products/detail', [
            'title' => htmlspecialchars($product['title']) . ' - ' . SITE_NAME,
            'description' => htmlspecialchars($product['short_description'] ?? $product['description']),
            'product' => $product,
            'screenshots' => $screenshots,
            'relatedProducts' => $relatedProducts
        ]);
    }
    
    public function search() {
        $query = $this->getQuery('q');
        
        if (strlen($query) < 2) {
            $this->json([]);
            return;
        }
        
        $products = $this->productModel->search($query, null, null, null, 'title', 'ASC', 10);
        
        // Format for AJAX response
        $results = array_map(function($product) {
            return [
                'id' => $product['id'],
                'title' => $product['title'],
                'price' => $product['price'],
                'thumbnail' => $product['thumbnail'] ?: 'assets/images/placeholder.jpg',
                'url' => SITE_URL . 'index.php?page=products&action=detail&id=' . $product['id']
            ];
        }, $products);
        
        $this->json($results);
    }
}
?>
