<?php
require_once 'config.php';
require_once 'core/Database.php';
require_once 'core/Controller.php';

try {
    $controller = new class extends Controller {
        public function test() {
            return "Database connection successful!";
        }
    };
    echo $controller->test();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
