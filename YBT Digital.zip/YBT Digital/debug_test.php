<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing Database class...<br>";

try {
    require_once 'config.php';
    echo "Config loaded successfully<br>";
    
    require_once 'core/Database.php';
    echo "Database.php loaded successfully<br>";
    
    if (class_exists('Database')) {
        echo "Database class exists<br>";
        
        $db = Database::getInstance();
        echo "Database instance created successfully<br>";
        
        echo "Test completed successfully!";
    } else {
        echo "Database class does not exist<br>";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
} catch (Error $e) {
    echo "Fatal Error: " . $e->getMessage() . "<br>";
    echo "Stack trace: " . $e->getTraceAsString() . "<br>";
}
?>
