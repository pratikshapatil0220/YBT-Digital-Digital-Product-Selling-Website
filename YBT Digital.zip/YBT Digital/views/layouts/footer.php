</main>

    <!-- Footer -->
    <footer class="footer bg-dark text-light py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <h5 class="mb-3"><?= SITE_NAME ?></h5>
                    <p>Your trusted marketplace for premium digital products. Discover software, templates, courses, and more.</p>
                    <div class="social-links d-flex gap-3 mt-3">
                        <a href="#" class="text-light"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="text-light"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6 mb-4">
                    <h6 class="mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?= SITE_URL ?>" class="text-light text-decoration-none">Home</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=products" class="text-light text-decoration-none">Products</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=support&action=faq" class="text-light text-decoration-none">FAQ</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=support&action=contact" class="text-light text-decoration-none">Contact</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="mb-3">Categories</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?= SITE_URL ?>index.php?page=products&category=software" class="text-light text-decoration-none">Software</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=products&category=templates" class="text-light text-decoration-none">Templates</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=products&category=ebooks" class="text-light text-decoration-none">E-books</a></li>
                        <li><a href="<?= SITE_URL ?>index.php?page=products&category=courses" class="text-light text-decoration-none">Courses</a></li>
                    </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 mb-4">
                    <h6 class="mb-3">Newsletter</h6>
                    <p>Subscribe to get updates on new products and special offers.</p>
                    <form class="newsletter-form" onsubmit="subscribeNewsletter(event)">
                        <div class="input-group">
                            <input type="email" class="form-control" placeholder="Your email" required>
                            <button type="submit" class="btn btn-primary">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <hr class="my-4 border-secondary">
            
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="<?= SITE_URL ?>index.php?page=privacy" class="text-light text-decoration-none me-3">Privacy Policy</a>
                    <a href="<?= SITE_URL ?>index.php?page=terms" class="text-light text-decoration-none">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button id="backToTop" class="back-to-top" onclick="scrollToTop()" style="display: none;">
        <i class="fas fa-arrow-up"></i>
    </button>

    <!-- JavaScript -->
    <script src="<?= SITE_URL ?>assets/js/main.js"></script>
    
    <script>
        // Theme Toggle
        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            
            document.querySelector('.theme-toggle').innerHTML = newTheme === 'dark' ? '☀️' : '🌙';
        }

        // Load saved theme
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', savedTheme);
            document.querySelector('.theme-toggle').innerHTML = savedTheme === 'dark' ? '☀️' : '🌙';
        });

        // Dropdown Toggle
        function toggleDropdown(id) {
            const dropdown = document.getElementById(id);
            if (dropdown) {
                dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
            }
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.matches('.dropdown-toggle')) {
                document.querySelectorAll('.dropdown-menu').forEach(dropdown => {
                    dropdown.style.display = 'none';
                });
            }
        });

        // Newsletter Subscription
        function subscribeNewsletter(event) {
            event.preventDefault();
            const email = event.target.querySelector('input[type="email"]').value;
            
            // Here you would typically send this to your backend
            alert('Thank you for subscribing with email: ' + email);
            event.target.reset();
        }

        // Back to Top
        window.addEventListener('scroll', function() {
            const backToTop = document.getElementById('backToTop');
            if (backToTop) {
                if (window.pageYOffset > 300) {
                    backToTop.style.display = 'block';
                } else {
                    backToTop.style.display = 'none';
                }
            }
        });

        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // Auto-hide flash messages
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);
    </script>

    <style>
        .dropdown {
            position: relative;
        }
        
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            min-width: 200px;
            z-index: 1000;
            display: none;
        }
        
        [data-theme="dark"] .dropdown-menu {
            background: #374151;
            border-color: var(--border-color);
        }
        
        .dropdown-item {
            display: block;
            padding: 12px 16px;
            color: var(--dark-color);
            text-decoration: none;
            transition: background-color 0.2s;
        }
        
        [data-theme="dark"] .dropdown-item {
            color: #f9fafb;
        }
        
        .dropdown-item:hover {
            background-color: rgba(99, 102, 241, 0.1);
            color: var(--primary-color);
        }
        
        .dropdown-divider {
            height: 1px;
            background-color: var(--border-color);
            margin: 8px 0;
        }
        
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            box-shadow: var(--shadow-lg);
            transition: var(--transition);
            z-index: 1000;
        }
        
        .back-to-top:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }
        
        .footer {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
        }
        
        .social-links a {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            transition: var(--transition);
        }
        
        .social-links a:hover {
            background: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .newsletter-form .input-group {
            display: flex;
            gap: 8px;
        }
        
        .newsletter-form input {
            flex: 1;
        }
        
        @media (max-width: 768px) {
            .footer .row > div {
                margin-bottom: 2rem;
            }
            
            .back-to-top {
                bottom: 80px;
                right: 20px;
            }
        }
    </style>
</body>
</html>
