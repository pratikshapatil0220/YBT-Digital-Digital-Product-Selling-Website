<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? SITE_NAME ?></title>
    <meta name="description" content="<?= $description ?? 'Digital Products Marketplace - Buy and sell premium digital products' ?>">
    <meta name="keywords" content="<?= $keywords ?? 'digital products, software, templates, ebooks, courses' ?>">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $title ?? SITE_NAME ?>">
    <meta property="og:description" content="<?= $description ?? 'Digital Products Marketplace' ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= SITE_URL ?>">
    <meta property="og:image" content="<?= SITE_URL ?>assets/images/og-image.jpg">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= SITE_URL ?>assets/images/favicon.ico">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?= SITE_URL ?>assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Theme Toggle -->
    <button class="theme-toggle" onclick="toggleTheme()" aria-label="Toggle theme">
        🌙
    </button>
</head>
<body>
    <!-- Flash Messages -->
    <?php if (!empty($flashMessages)): ?>
        <div class="flash-messages">
            <?php foreach ($flashMessages as $type => $message): ?>
                <div class="alert alert-<?= $type ?> alert-dismissible">
                    <?= $message ?>
                    <button type="button" class="close" onclick="this.parentElement.remove()">&times;</button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="navbar-content d-flex justify-between align-center">
                <a href="<?= SITE_URL ?>" class="navbar-brand">
                    <i class="fas fa-store"></i> <?= SITE_NAME ?>
                </a>
                
                <!-- Desktop Navigation -->
                <ul class="navbar-nav d-none d-md-flex">
                    <li><a href="<?= SITE_URL ?>" class="nav-link">Home</a></li>
                    <li><a href="<?= SITE_URL ?>index.php?page=products" class="nav-link">Products</a></li>
                    <li><a href="<?= SITE_URL ?>index.php?page=support&action=contact" class="nav-link">Contact</a></li>
                    <li><a href="<?= SITE_URL ?>index.php?page=support&action=faq" class="nav-link">FAQ</a></li>
                </ul>
                
                <!-- User Actions -->
                <div class="navbar-actions d-flex align-center gap-3">
                    <!-- Search -->
                    <div class="search-container position-relative">
                        <form action="<?= SITE_URL ?>index.php?page=products" method="GET" class="d-flex">
                            <input type="hidden" name="page" value="products">
                            <input type="text" name="search" class="form-control search-input" placeholder="Search products..." style="min-width: 200px;">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fas fa-search"></i>
                            </button>
                        </form>
                    </div>
                    
                    <?php if (isLoggedIn()): ?>
                        <!-- Cart -->
                        <a href="<?= SITE_URL ?>index.php?page=cart" class="btn btn-outline position-relative">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="cart-count" style="display: none;">0</span>
                        </a>
                        
                        <!-- User Menu -->
                        <div class="dropdown">
                            <button class="btn btn-outline dropdown-toggle" onclick="toggleDropdown('userDropdown')">
                                <i class="fas fa-user"></i> <?= $_SESSION['user_name'] ?>
                            </button>
                            <div id="userDropdown" class="dropdown-menu">
                                <a href="<?= SITE_URL ?>index.php?page=auth&action=profile" class="dropdown-item">
                                    <i class="fas fa-user-circle"></i> Profile
                                </a>
                                <a href="<?= SITE_URL ?>index.php?page=orders" class="dropdown-item">
                                    <i class="fas fa-box"></i> My Orders
                                </a>
                                <a href="<?= SITE_URL ?>index.php?page=downloads" class="dropdown-item">
                                    <i class="fas fa-download"></i> Downloads
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="<?= SITE_URL ?>index.php?page=auth&action=logout" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="<?= SITE_URL ?>index.php?page=auth&action=login" class="btn btn-outline">Login</a>
                        <a href="<?= SITE_URL ?>index.php?page=auth&action=signup" class="btn btn-primary">Sign Up</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Mobile Navigation -->
    <nav class="mobile-nav d-md-none">
        <div class="container">
            <div class="mobile-nav-items">
                <a href="<?= SITE_URL ?>" class="mobile-nav-item">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
                <a href="<?= SITE_URL ?>index.php?page=products" class="mobile-nav-item">
                    <i class="fas fa-th-large"></i>
                    <span>Products</span>
                </a>
                <a href="<?= SITE_URL ?>index.php?page=cart" class="mobile-nav-item position-relative">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Cart</span>
                    <span class="cart-count" style="display: none;">0</span>
                </a>
                <?php if (isLoggedIn()): ?>
                    <a href="<?= SITE_URL ?>index.php?page=orders" class="mobile-nav-item">
                        <i class="fas fa-user"></i>
                        <span>Account</span>
                    </a>
                <?php else: ?>
                    <a href="<?= SITE_URL ?>index.php?page=auth&action=login" class="mobile-nav-item">
                        <i class="fas fa-sign-in-alt"></i>
                        <span>Login</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <?php if (isset($hero) && $hero): ?>
            <!-- Hero Section -->
            <section class="hero">
                <div class="container">
                    <h1><?= $hero['title'] ?? 'Welcome to ' . SITE_NAME ?></h1>
                    <p><?= $hero['subtitle'] ?? 'Discover amazing digital products' ?></p>
                    <?php if (isset($hero['cta'])): ?>
                        <a href="<?= $hero['cta_url'] ?? '#' ?>" class="btn btn-lg btn-light">
                            <?= $hero['cta'] ?>
                        </a>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
