<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">Discover Premium Digital Products</h1>
                <p class="lead mb-4">Software, Templates, Courses, and More - All in One Place. Transform your ideas into reality with our curated collection.</p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="<?= SITE_URL ?>index.php?page=products" class="btn btn-light btn-lg">
                        <i class="fas fa-rocket me-2"></i>Explore Products
                    </a>
                    <a href="#featured" class="btn btn-outline-light btn-lg">
                        <i class="fas fa-star me-2"></i>Featured Items
                    </a>
                </div>
                
                <!-- Stats -->
                <div class="row mt-5">
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold">500+</h3>
                            <p class="mb-0">Digital Products</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold">10K+</h3>
                            <p class="mb-0">Happy Customers</p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="text-center">
                            <h3 class="fw-bold">24/7</h3>
                            <p class="mb-0">Support</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-image text-center">
                    <img src="assets/images/hero-illustration.svg" alt="Digital Products" class="img-fluid" style="max-height: 400px;">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Browse Categories</h2>
            <p class="text-muted">Find exactly what you're looking for</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($categories as $category): ?>
                <div class="col-lg-2 col-md-4 col-6">
                    <a href="<?= SITE_URL ?>index.php?page=products&category=<?= $category['slug'] ?>" 
                       class="category-card text-center text-decoration-none">
                        <div class="category-icon mb-3">
                            <i class="<?= $this->getCategoryIcon($category['slug']) ?>"></i>
                        </div>
                        <h6 class="mb-1"><?= htmlspecialchars($category['name']) ?></h6>
                        <small class="text-muted"><?= rand(10, 100) ?> Products</small>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section id="featured" class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Featured Products</h2>
            <p class="text-muted">Hand-picked products just for you</p>
        </div>
        
        <div class="product-grid">
            <?php foreach ($featuredProducts as $product): ?>
                <div class="product-card">
                    <div class="product-image-container">
                        <img src="<?= $product['thumbnail'] ?: 'assets/images/placeholder.jpg' ?>" 
                             alt="<?= htmlspecialchars($product['title']) ?>" 
                             class="product-image">
                        <div class="product-overlay">
                            <a href="<?= SITE_URL ?>index.php?page=products&action=detail&id=<?= $product['id'] ?>" 
                               class="btn btn-primary btn-sm">
                                <i class="fas fa-eye me-1"></i>View Details
                            </a>
                        </div>
                    </div>
                    <div class="product-content">
                        <div class="product-category mb-2">
                            <span class="badge bg-primary"><?= htmlspecialchars($product['category_name'] ?? 'General') ?></span>
                        </div>
                        <h5 class="product-title">
                            <a href="<?= SITE_URL ?>index.php?page=products&action=detail&id=<?= $product['id'] ?>" 
                               class="text-decoration-none">
                                <?= htmlspecialchars($product['title']) ?>
                            </a>
                        </h5>
                        <p class="product-description text-muted small">
                            <?= htmlspecialchars(substr($product['short_description'] ?? $product['description'], 0, 100)) ?>...
                        </p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="product-price"><?= formatPrice($product['price']) ?></span>
                            <button class="btn btn-primary btn-sm add-to-cart" data-product-id="<?= $product['id'] ?>">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?= SITE_URL ?>index.php?page=products" class="btn btn-outline-primary">
                View All Products <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>
</section>

<!-- Latest Products -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Latest Arrivals</h2>
            <p class="text-muted">Fresh products added to our collection</p>
        </div>
        
        <div class="row g-4">
            <?php foreach (array_slice($latestProducts, 0, 6) as $product): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card h-100 product-card">
                        <div class="product-image-container">
                            <img src="<?= $product['thumbnail'] ?: 'assets/images/placeholder.jpg' ?>" 
                                 alt="<?= htmlspecialchars($product['title']) ?>" 
                                 class="card-img-top product-image">
                            <span class="badge bg-success position-absolute top-0 start-0 m-2">New</span>
                        </div>
                        <div class="card-body">
                            <div class="product-category mb-2">
                                <span class="badge bg-primary"><?= htmlspecialchars($product['category_name'] ?? 'General') ?></span>
                            </div>
                            <h5 class="card-title">
                                <a href="<?= SITE_URL ?>index.php?page=products&action=detail&id=<?= $product['id'] ?>" 
                                   class="text-decoration-none">
                                    <?= htmlspecialchars($product['title']) ?>
                                </a>
                            </h5>
                            <p class="card-text text-muted small">
                                <?= htmlspecialchars(substr($product['short_description'] ?? $product['description'], 0, 80)) ?>...
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="h5 text-primary mb-0"><?= formatPrice($product['price']) ?></span>
                                <button class="btn btn-primary btn-sm add-to-cart" data-product-id="<?= $product['id'] ?>">
                                    <i class="fas fa-cart-plus"></i> Add to Cart
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">What Our Customers Say</h2>
            <p class="text-muted">Real feedback from real customers</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($testimonials as $testimonial): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body">
                            <div class="rating mb-3">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star text-warning"></i>
                                <?php endfor; ?>
                            </div>
                            <blockquote class="mb-3">
                                <p class="text-muted">"<?= htmlspecialchars($testimonial['content']) ?>"</p>
                            </blockquote>
                            <div class="d-flex align-items-center">
                                <img src="<?= $testimonial['avatar'] ?: 'assets/images/placeholder-avatar.jpg' ?>" 
                                     alt="<?= htmlspecialchars($testimonial['name']) ?>" 
                                     class="rounded-circle me-3" width="50" height="50">
                                <div>
                                    <h6 class="mb-0"><?= htmlspecialchars($testimonial['name']) ?></h6>
                                    <small class="text-muted"><?= htmlspecialchars($testimonial['role']) ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-3">Ready to Get Started?</h2>
                <p class="lead mb-0">Join thousands of satisfied customers and discover amazing digital products today!</p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <a href="<?= SITE_URL ?>index.php?page=products" class="btn btn-light btn-lg">
                    <i class="fas fa-shopping-bag me-2"></i>Start Shopping
                </a>
            </div>
        </div>
    </div>
</section>

<?php
// Helper function to get category icons
function getCategoryIcon($slug) {
    $icons = [
        'software' => 'fas fa-desktop fa-2x text-primary',
        'templates' => 'fas fa-palette fa-2x text-success',
        'ebooks' => 'fas fa-book fa-2x text-info',
        'graphics' => 'fas fa-image fa-2x text-warning',
        'courses' => 'fas fa-graduation-cap fa-2x text-danger'
    ];
    
    return $icons[$slug] ?? 'fas fa-folder fa-2x text-secondary';
}
?>

<style>
.category-card {
    display: block;
    padding: 2rem 1rem;
    background: white;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    color: var(--dark-color);
}

.category-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
    color: var(--primary-color);
}

.category-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(99, 102, 241, 0.1);
    border-radius: 50%;
}

.product-image-container {
    position: relative;
    overflow: hidden;
}

.product-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: var(--transition);
}

.product-image-container:hover .product-overlay {
    opacity: 1;
}

.hero {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    padding: 80px 0;
}

@media (max-width: 768px) {
    .hero {
        padding: 60px 0;
    }
    
    .hero h1 {
        font-size: 2rem;
    }
    
    .product-grid {
        grid-template-columns: 1fr;
    }
}
</style>
