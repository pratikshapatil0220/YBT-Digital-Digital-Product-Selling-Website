<div class="container py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="fw-bold mb-2">Digital Products</h1>
            <p class="text-muted">Discover our collection of premium digital products</p>
        </div>
    </div>
    
    <div class="row">
        <!-- Filters Sidebar -->
        <div class="col-lg-3 col-md-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-filter me-2"></i>Filters
                        <?php if (!empty($filters['search']) || !empty($filters['category']) || !empty($filters['min_price']) || !empty($filters['max_price'])): ?>
                            <a href="<?= SITE_URL ?>index.php?page=products" class="btn btn-sm btn-outline-secondary float-end">
                                Clear All
                            </a>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <form method="GET" id="filterForm">
                        <input type="hidden" name="page" value="products">
                        
                        <!-- Search -->
                        <div class="mb-3">
                            <label class="form-label">Search</label>
                            <input type="text" name="search" class="form-control" 
                                   value="<?= htmlspecialchars($filters['search']) ?>" 
                                   placeholder="Search products...">
                        </div>
                        
                        <!-- Categories -->
                        <div class="mb-3">
                            <label class="form-label">Categories</label>
                            <div class="category-filters">
                                <?php foreach ($categories as $category): ?>
                                    <div class="form-check">
                                        <input type="radio" name="category" 
                                               id="cat_<?= $category['id'] ?>" 
                                               value="<?= $category['slug'] ?>"
                                               class="form-check-input"
                                               <?= ($filters['category'] === $category['slug']) ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="cat_<?= $category['id'] ?>">
                                            <?= htmlspecialchars($category['name']) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- Price Range -->
                        <div class="mb-3">
                            <label class="form-label">Price Range</label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="number" name="min_price" class="form-control" 
                                           placeholder="Min" value="<?= htmlspecialchars($filters['min_price']) ?>"
                                           min="0" step="0.01">
                                </div>
                                <div class="col-6">
                                    <input type="number" name="max_price" class="form-control" 
                                           placeholder="Max" value="<?= htmlspecialchars($filters['max_price']) ?>"
                                           min="0" step="0.01">
                                </div>
                            </div>
                            <?php if ($priceRange): ?>
                                <small class="text-muted">
                                    Range: $<?= number_format($priceRange['min_price'], 2) ?> - $<?= number_format($priceRange['max_price'], 2) ?>
                                </small>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Sort -->
                        <div class="mb-3">
                            <label class="form-label">Sort By</label>
                            <select name="sort" class="form-select">
                                <option value="created_at" <?= ($filters['sort'] === 'created_at') ? 'selected' : '' ?>>
                                    Latest First
                                </option>
                                <option value="title" <?= ($filters['sort'] === 'title') ? 'selected' : '' ?>>
                                    Name (A-Z)
                                </option>
                                <option value="price" <?= ($filters['sort'] === 'price') ? 'selected' : '' ?>>
                                    Price (Low to High)
                                </option>
                                <option value="price" <?= ($filters['sort'] === 'price' && $filters['order'] === 'DESC') ? 'selected' : '' ?>>
                                    Price (High to Low)
                                </option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i>Apply Filters
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Products Grid -->
        <div class="col-lg-9 col-md-8">
            <!-- Results Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h5 class="mb-0">
                        <?= $pagination['total_items'] ?> Products Found
                        <?php if (!empty($filters['search'])): ?>
                            for "<?= htmlspecialchars($filters['search']) ?>"
                        <?php endif; ?>
                    </h5>
                </div>
                
                <!-- View Toggle -->
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-secondary active" onclick="setViewMode('grid')">
                        <i class="fas fa-th"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary" onclick="setViewMode('list')">
                        <i class="fas fa-list"></i>
                    </button>
                </div>
            </div>
            
            <!-- Products Grid -->
            <?php if (!empty($products)): ?>
                <div id="productsContainer" class="product-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <div class="product-image-container">
                                <img src="<?= $product['thumbnail'] ?: 'assets/images/placeholder.jpg' ?>" 
                                     alt="<?= htmlspecialchars($product['title']) ?>" 
                                     class="product-image">
                                <div class="product-overlay">
                                    <a href="<?= SITE_URL ?>index.php?page=products&action=detail&id=<?= $product['id'] ?>" 
                                       class="btn btn-primary btn-sm me-2">
                                        <i class="fas fa-eye me-1"></i>View
                                    </a>
                                    <button class="btn btn-success btn-sm add-to-cart" data-product-id="<?= $product['id'] ?>">
                                        <i class="fas fa-cart-plus me-1"></i>Add
                                    </button>
                                </div>
                            </div>
                            <div class="product-content">
                                <div class="product-category mb-2">
                                    <span class="badge bg-primary"><?= htmlspecialchars($product['category_name'] ?? 'General') ?></span>
                                </div>
                                <h5 class="product-title">
                                    <a href="<?= SITE_URL ?>index.php?page=products&action=detail&id=<?= $product['id'] ?>" 
                                       class="text-decoration-none">
                                        <?= htmlspecialchars($product['title']) ?>
                                    </a>
                                </h5>
                                <p class="product-description text-muted small">
                                    <?= htmlspecialchars(substr($product['short_description'] ?? $product['description'], 0, 100)) ?>...
                                </p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="product-price"><?= formatPrice($product['price']) ?></span>
                                    <div class="product-actions">
                                        <button class="btn btn-outline-primary btn-sm add-to-cart" 
                                                data-product-id="<?= $product['id'] ?>">
                                            <i class="fas fa-cart-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($pagination['total_pages'] > 1): ?>
                    <nav aria-label="Products pagination" class="mt-5">
                        <ul class="pagination justify-content-center">
                            <?php if ($pagination['has_prev']): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= $this->buildPageUrl($pagination['current_page'] - 1) ?>">
                                        <i class="fas fa-chevron-left"></i> Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $pagination['current_page'] - 2); $i <= min($pagination['total_pages'], $pagination['current_page'] + 2); $i++): ?>
                                <li class="page-item <?= ($i === $pagination['current_page']) ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= $this->buildPageUrl($i) ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($pagination['has_next']): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= $this->buildPageUrl($pagination['current_page'] + 1) ?>">
                                        Next <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4>No products found</h4>
                    <p class="text-muted">Try adjusting your filters or search terms</p>
                    <a href="<?= SITE_URL ?>index.php?page=products" class="btn btn-primary">
                        Clear Filters
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
// Helper function to build pagination URLs
function buildPageUrl($page) {
    $params = $_GET;
    $params['page'] = $page;
    unset($params['page']); // Remove page from base URL
    $baseUrl = SITE_URL . 'index.php?page=products';
    
    if (!empty($params)) {
        $queryString = http_build_query($params);
        $baseUrl .= '&' . $queryString;
    }
    
    return $baseUrl . '&page=' . $page;
}
?>

<style>
.product-image-container {
    position: relative;
    overflow: hidden;
    aspect-ratio: 16/9;
}

.product-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.product-image-container:hover .product-overlay {
    opacity: 1;
}

.category-filters {
    max-height: 200px;
    overflow-y: auto;
}

.category-filters::-webkit-scrollbar {
    width: 4px;
}

.category-filters::-webkit-scrollbar-track {
    background: #f1f1f1;
}

.category-filters::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 2px;
}

.category-filters::-webkit-scrollbar-thumb:hover {
    background: #555;
}

/* List view styles */
.products-list-view .product-card {
    display: flex;
    flex-direction: row;
    height: auto;
}

.products-list-view .product-image-container {
    width: 200px;
    flex-shrink: 0;
}

.products-list-view .product-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

@media (max-width: 768px) {
    .products-list-view .product-card {
        flex-direction: column;
    }
    
    .products-list-view .product-image-container {
        width: 100%;
    }
}
</style>

<script>
function setViewMode(mode) {
    const container = document.getElementById('productsContainer');
    const buttons = document.querySelectorAll('.btn-group .btn');
    
    buttons.forEach(btn => btn.classList.remove('active'));
    
    if (mode === 'list') {
        container.classList.add('products-list-view');
        buttons[1].classList.add('active');
    } else {
        container.classList.remove('products-list-view');
        buttons[0].classList.add('active');
    }
    
    // Save preference
    localStorage.setItem('productViewMode', mode);
}

// Load saved view mode
document.addEventListener('DOMContentLoaded', function() {
    const savedMode = localStorage.getItem('productViewMode') || 'grid';
    setViewMode(savedMode);
});

// Auto-submit filters on change
document.querySelectorAll('#filterForm input, #filterForm select').forEach(element => {
    element.addEventListener('change', function() {
        if (this.type !== 'text' && this.type !== 'number') {
            document.getElementById('filterForm').submit();
        }
    });
});

// Search on enter key
document.querySelector('input[name="search"]').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        document.getElementById('filterForm').submit();
    }
});
</script>
