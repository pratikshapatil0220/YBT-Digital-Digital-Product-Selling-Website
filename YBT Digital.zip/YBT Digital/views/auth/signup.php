<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="card shadow-lg">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <h2 class="mb-3">Create Account</h2>
                        <p class="text-muted">Join our community and start exploring amazing digital products</p>
                    </div>
                    
                    <form method="POST" data-validate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="form-label">Full Name</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="fas fa-user"></i>
                                        </span>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               placeholder="Enter your name" required>
                                    </div>
                                    <?php if (isset($errors['name'])): ?>
                                        <div class="text-danger mt-1 small"><?= $errors['name'] ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="fas fa-phone"></i>
                                        </span>
                                        <input type="tel" class="form-control" id="phone" name="phone" 
                                               placeholder="Enter your phone">
                                    </div>
                                    <?php if (isset($errors['phone'])): ?>
                                        <div class="text-danger mt-1 small"><?= $errors['phone'] ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-envelope"></i>
                                </span>
                                <input type="email" class="form-control" id="email" name="email" 
                                       placeholder="Enter your email" required>
                            </div>
                            <?php if (isset($errors['email'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['email'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-lock"></i>
                                </span>
                                <input type="password" class="form-control" id="password" name="password" 
                                       placeholder="Create a password" required minlength="8">
                                <button type="button" class="input-group-text" onclick="togglePassword('password')">
                                    <i class="fas fa-eye" id="password-toggle"></i>
                                </button>
                            </div>
                            <div class="form-text text-muted">Password must be at least 8 characters long</div>
                            <?php if (isset($errors['password'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['password'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-lock"></i>
                                </span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                       placeholder="Confirm your password" required>
                                <button type="button" class="input-group-text" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye" id="confirm_password-toggle"></i>
                                </button>
                            </div>
                            <?php if (isset($errors['confirm_password'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['confirm_password'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (isset($errors['general'])): ?>
                            <div class="alert alert-danger">
                                <?= $errors['general'] ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                                <label class="form-check-label" for="terms">
                                    I agree to the <a href="#" class="text-primary">Terms and Conditions</a> 
                                    and <a href="#" class="text-primary">Privacy Policy</a>
                                </label>
                            </div>
                            <?php if (isset($errors['terms'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['terms'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 py-3">
                            <i class="fas fa-user-plus me-2"></i>
                            Create Account
                        </button>
                    </form>
                    
                    <div class="text-center mt-4">
                        <p class="mb-0">
                            Already have an account? 
                            <a href="<?= SITE_URL ?>index.php?page=auth&action=login" class="text-primary text-decoration-none fw-semibold">
                                Sign In
                            </a>
                        </p>
                    </div>
                    
                    <div class="divider my-4">
                        <span class="text-muted">OR</span>
                    </div>
                    
                    <div class="social-login">
                        <button class="btn btn-outline-primary w-100 mb-2" onclick="socialLogin('google')">
                            <i class="fab fa-google me-2"></i>
                            Sign up with Google
                        </button>
                        <button class="btn btn-outline-dark w-100" onclick="socialLogin('github')">
                            <i class="fab fa-github me-2"></i>
                            Sign up with GitHub
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Benefits Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <div class="benefit-item">
                    <div class="benefit-icon mb-3">
                        <i class="fas fa-shield-alt text-primary" style="font-size: 2.5rem;"></i>
                    </div>
                    <h5>Secure & Safe</h5>
                    <p class="text-muted">Your data is protected with industry-standard encryption</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="benefit-item">
                    <div class="benefit-icon mb-3">
                        <i class="fas fa-download text-primary" style="font-size: 2.5rem;"></i>
                    </div>
                    <h5>Instant Downloads</h5>
                    <p class="text-muted">Get your products immediately after purchase</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="benefit-item">
                    <div class="benefit-icon mb-3">
                        <i class="fas fa-headset text-primary" style="font-size: 2.5rem;"></i>
                    </div>
                    <h5>24/7 Support</h5>
                    <p class="text-muted">Our team is always here to help you</p>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.input-group-text {
    background: var(--light-color);
    border: 2px solid var(--border-color);
    color: var(--text-muted);
}

[data-theme="dark"] .input-group-text {
    background: #374151;
    border-color: var(--border-color);
}

.form-control:focus + .input-group-text {
    border-color: var(--primary-color);
}

.divider {
    text-align: center;
    position: relative;
}

.divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--border-color);
}

.divider span {
    background: white;
    padding: 0 1rem;
    position: relative;
    z-index: 1;
}

[data-theme="dark"] .divider span {
    background: #374151;
}

.social-login .btn {
    transition: var(--transition);
}

.social-login .btn:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.benefit-item {
    padding: 1rem;
}

.benefit-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(99, 102, 241, 0.1);
    border-radius: 50%;
}

@media (max-width: 576px) {
    .card-body {
        padding: 2rem !important;
    }
}
</style>

<script>
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const toggle = document.getElementById(fieldId + '-toggle');
    
    if (field.type === 'password') {
        field.type = 'text';
        toggle.classList.remove('fa-eye');
        toggle.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        toggle.classList.remove('fa-eye-slash');
        toggle.classList.add('fa-eye');
    }
}

function socialLogin(provider) {
    // This would integrate with OAuth providers
    alert(`${provider} signup would be implemented here with OAuth integration`);
}

// Password strength indicator
document.getElementById('password').addEventListener('input', function(e) {
    const password = e.target.value;
    const strength = calculatePasswordStrength(password);
    updatePasswordStrength(strength);
});

function calculatePasswordStrength(password) {
    let strength = 0;
    
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^a-zA-Z0-9]/.test(password)) strength++;
    
    return strength;
}

function updatePasswordStrength(strength) {
    const strengthBar = document.getElementById('password-strength') || createPasswordStrengthBar();
    const colors = ['#dc3545', '#ffc107', '#28a745', '#28a745', '#28a745'];
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    
    strengthBar.style.width = (strength * 20) + '%';
    strengthBar.style.backgroundColor = colors[strength];
    strengthBar.nextElementSibling.textContent = labels[strength];
}

function createPasswordStrengthBar() {
    const container = document.createElement('div');
    container.className = 'mt-2';
    container.innerHTML = `
        <div class="progress" style="height: 5px;">
            <div id="password-strength" class="progress-bar" style="width: 0%; transition: all 0.3s;"></div>
        </div>
        <small class="text-muted mt-1 d-block">Password strength: <span id="strength-label">Very Weak</span></small>
    `;
    
    document.getElementById('password').parentNode.appendChild(container);
    return document.getElementById('password-strength');
}
</script>
