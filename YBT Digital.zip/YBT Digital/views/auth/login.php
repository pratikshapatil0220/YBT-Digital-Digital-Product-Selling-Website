<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="card shadow-lg">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <h2 class="mb-3">Welcome Back</h2>
                        <p class="text-muted">Sign in to your account</p>
                    </div>
                    
                    <form method="POST" data-validate>
                        <div class="form-group">
                            <label for="email" class="form-label">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-envelope"></i>
                                </span>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?= $_COOKIE['remember_email'] ?? '' ?>" 
                                       placeholder="Enter your email" required>
                            </div>
                            <?php if (isset($errors['email'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['email'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-lock"></i>
                                </span>
                                <input type="password" class="form-control" id="password" name="password" 
                                       placeholder="Enter your password" required>
                                <button type="button" class="input-group-text" onclick="togglePassword('password')">
                                    <i class="fas fa-eye" id="password-toggle"></i>
                                </button>
                            </div>
                            <?php if (isset($errors['password'])): ?>
                                <div class="text-danger mt-1 small"><?= $errors['password'] ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (isset($errors['login'])): ?>
                            <div class="alert alert-danger">
                                <?= $errors['login'] ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">
                                    Remember me
                                </label>
                            </div>
                            <a href="<?= SITE_URL ?>index.php?page=auth&action=forgot" class="text-primary text-decoration-none">
                                Forgot Password?
                            </a>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 py-3">
                            <i class="fas fa-sign-in-alt me-2"></i>
                            Sign In
                        </button>
                    </form>
                    
                    <div class="text-center mt-4">
                        <p class="mb-0">
                            Don't have an account? 
                            <a href="<?= SITE_URL ?>index.php?page=auth&action=signup" class="text-primary text-decoration-none fw-semibold">
                                Sign Up
                            </a>
                        </p>
                    </div>
                    
                    <div class="divider my-4">
                        <span class="text-muted">OR</span>
                    </div>
                    
                    <div class="social-login">
                        <button class="btn btn-outline-primary w-100 mb-2" onclick="socialLogin('google')">
                            <i class="fab fa-google me-2"></i>
                            Continue with Google
                        </button>
                        <button class="btn btn-outline-dark w-100" onclick="socialLogin('github')">
                            <i class="fab fa-github me-2"></i>
                            Continue with GitHub
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.input-group-text {
    background: var(--light-color);
    border: 2px solid var(--border-color);
    color: var(--text-muted);
}

[data-theme="dark"] .input-group-text {
    background: #374151;
    border-color: var(--border-color);
}

.form-control:focus + .input-group-text {
    border-color: var(--primary-color);
}

.divider {
    text-align: center;
    position: relative;
}

.divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--border-color);
}

.divider span {
    background: white;
    padding: 0 1rem;
    position: relative;
    z-index: 1;
}

[data-theme="dark"] .divider span {
    background: #374151;
}

.social-login .btn {
    transition: var(--transition);
}

.social-login .btn:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

@media (max-width: 576px) {
    .card-body {
        padding: 2rem !important;
    }
}
</style>

<script>
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const toggle = document.getElementById(fieldId + '-toggle');
    
    if (field.type === 'password') {
        field.type = 'text';
        toggle.classList.remove('fa-eye');
        toggle.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        toggle.classList.remove('fa-eye-slash');
        toggle.classList.add('fa-eye');
    }
}

function socialLogin(provider) {
    // This would integrate with OAuth providers
    alert(`${provider} login would be implemented here with OAuth integration`);
}
</script>
