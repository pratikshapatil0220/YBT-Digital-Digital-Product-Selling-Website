<?php
require_once __DIR__ . '/../core/Database.php';

class Product {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function create($data) {
        $sql = "INSERT INTO products (title, slug, description, short_description, price, category_id, file_path, file_size, file_type, thumbnail, screenshots, tags, status, featured, download_limit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $data['title'],
            $data['slug'],
            $data['description'],
            $data['short_description'] ?? null,
            $data['price'],
            $data['category_id'] ?? null,
            $data['file_path'] ?? null,
            $data['file_size'] ?? null,
            $data['file_type'] ?? null,
            $data['thumbnail'] ?? null,
            $data['screenshots'] ? json_encode($data['screenshots']) : null,
            $data['tags'] ?? null,
            $data['status'] ?? 'active',
            $data['featured'] ?? false,
            $data['download_limit'] ?? 5
        ];
        
        try {
            $this->db->query($sql, $params);
            return $this->db->getConnection()->lastInsertId();
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                throw new Exception('Product with this slug already exists');
            }
            throw $e;
        }
    }
    
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        $updatableFields = [
            'title', 'slug', 'description', 'short_description', 'price',
            'category_id', 'file_path', 'file_size', 'file_type', 'thumbnail',
            'tags', 'status', 'featured', 'download_limit'
        ];
        
        foreach ($updatableFields as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $params[] = $field === 'screenshots' ? json_encode($data[$field]) : $data[$field];
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
        $params[] = $id;
        
        return $this->db->query($sql, $params);
    }
    
    public function delete($id) {
        // Check if product has orders
        $hasOrders = $this->db->count('order_items', 'product_id = ?', [$id]) > 0;
        
        if ($hasOrders) {
            // Just deactivate instead of deleting
            return $this->update($id, ['status' => 'inactive']);
        }
        
        $sql = "DELETE FROM products WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }
    
    public function findById($id) {
        $sql = "
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.id = ?
        ";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function findBySlug($slug) {
        $sql = "
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.slug = ? AND p.status = 'active'
        ";
        return $this->db->fetch($sql, [$slug]);
    }
    
    public function getAll($status = null, $limit = null, $offset = null) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
        ";
        
        $params = [];
        
        if ($status) {
            $sql .= " WHERE p.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY p.created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT $limit";
            if ($offset) {
                $sql .= " OFFSET $offset";
            }
        }
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getFeatured($limit = 8) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active' AND p.featured = TRUE
            ORDER BY p.created_at DESC
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$limit]);
    }
    
    public function getByCategory($categoryId, $limit = null) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active' AND p.category_id = ?
            ORDER BY p.created_at DESC
        ";
        
        $params = [$categoryId];
        
        if ($limit) {
            $sql .= " LIMIT ?";
            $params[] = $limit;
        }
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function search($query, $categoryId = null, $minPrice = null, $maxPrice = null, $sortBy = 'created_at', $sortOrder = 'DESC', $limit = ITEMS_PER_PAGE, $offset = 0) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active'
        ";
        
        $params = [];
        
        // Search query
        if (!empty($query)) {
            $sql .= " AND (p.title LIKE ? OR p.description LIKE ? OR p.tags LIKE ?)";
            $searchTerm = "%$query%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Category filter
        if ($categoryId) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
        }
        
        // Price range filter
        if ($minPrice !== null) {
            $sql .= " AND p.price >= ?";
            $params[] = $minPrice;
        }
        
        if ($maxPrice !== null) {
            $sql .= " AND p.price <= ?";
            $params[] = $maxPrice;
        }
        
        // Sorting
        $allowedSortFields = ['title', 'price', 'created_at'];
        $allowedSortOrders = ['ASC', 'DESC'];
        
        if (in_array($sortBy, $allowedSortFields) && in_array($sortOrder, $allowedSortOrders)) {
            $sql .= " ORDER BY p.$sortBy $sortOrder";
        } else {
            $sql .= " ORDER BY p.created_at DESC";
        }
        
        // Pagination
        if ($limit) {
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
        }
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function countSearch($query = null, $categoryId = null, $minPrice = null, $maxPrice = null) {
        $sql = "SELECT COUNT(*) as total FROM products p WHERE p.status = 'active'";
        $params = [];
        
        if (!empty($query)) {
            $sql .= " AND (p.title LIKE ? OR p.description LIKE ? OR p.tags LIKE ?)";
            $searchTerm = "%$query%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if ($categoryId) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
        }
        
        if ($minPrice !== null) {
            $sql .= " AND p.price >= ?";
            $params[] = $minPrice;
        }
        
        if ($maxPrice !== null) {
            $sql .= " AND p.price <= ?";
            $params[] = $maxPrice;
        }
        
        $result = $this->db->fetch($sql, $params);
        return $result['total'];
    }
    
    public function getRelatedProducts($productId, $categoryId, $limit = 4) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active' AND p.id != ? AND p.category_id = ?
            ORDER BY RAND()
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$productId, $categoryId, $limit]);
    }
    
    public function getPopularProducts($limit = 8) {
        $sql = "
            SELECT p.*, c.name as category_name, COUNT(oi.id) as sales_count
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN order_items oi ON p.id = oi.product_id
            LEFT JOIN orders o ON oi.order_id = o.id
            WHERE p.status = 'active' AND o.payment_status = 'completed'
            GROUP BY p.id
            ORDER BY sales_count DESC, p.created_at DESC
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$limit]);
    }
    
    public function getLatestProducts($limit = 8) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active'
            ORDER BY p.created_at DESC
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$limit]);
    }
    
    public function updateStatus($id, $status) {
        $sql = "UPDATE products SET status = ? WHERE id = ?";
        return $this->db->query($sql, [$status, $id]);
    }
    
    public function toggleFeatured($id) {
        $sql = "UPDATE products SET featured = NOT featured WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }
    
    public function getStats() {
        $stats = [];
        
        // Total products
        $stats['total'] = $this->db->count('products');
        
        // Active products
        $stats['active'] = $this->db->count('products', 'status = ?', ['active']);
        
        // Inactive products
        $stats['inactive'] = $this->db->count('products', 'status = ?', ['inactive']);
        
        // Featured products
        $stats['featured'] = $this->db->count('products', 'featured = ?', [true]);
        
        // Products added this month
        $stats['this_month'] = $this->db->count(
            'products',
            'created_at >= DATE_FORMAT(NOW(), "%Y-%m-01")'
        );
        
        // Total value of all products
        $result = $this->db->fetch("SELECT SUM(price) as total_value FROM products WHERE status = 'active'");
        $stats['total_value'] = $result['total_value'] ?? 0;
        
        // Average product price
        $result = $this->db->fetch("SELECT AVG(price) as avg_price FROM products WHERE status = 'active'");
        $stats['avg_price'] = $result['avg_price'] ?? 0;
        
        return $stats;
    }
    
    public function generateSlug($title, $id = null) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        $originalSlug = $slug;
        $counter = 1;
        
        while (true) {
            $sql = "SELECT id FROM products WHERE slug = ?";
            $params = [$slug];
            
            if ($id) {
                $sql .= " AND id != ?";
                $params[] = $id;
            }
            
            $existing = $this->db->fetch($sql, $params);
            
            if (!$existing) {
                break;
            }
            
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    public function getPriceRange() {
        $sql = "SELECT MIN(price) as min_price, MAX(price) as max_price FROM products WHERE status = 'active'";
        return $this->db->fetch($sql);
    }
    
    public function getProductsByPriceRange($minPrice, $maxPrice, $limit = null) {
        $sql = "
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'active' AND p.price BETWEEN ? AND ?
            ORDER BY p.price ASC
        ";
        
        $params = [$minPrice, $maxPrice];
        
        if ($limit) {
            $sql .= " LIMIT ?";
            $params[] = $limit;
        }
        
        return $this->db->fetchAll($sql, $params);
    }
}
?>
