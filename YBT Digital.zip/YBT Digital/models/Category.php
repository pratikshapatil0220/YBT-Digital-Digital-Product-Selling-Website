<?php
require_once __DIR__ . '/../core/Database.php';

class Category {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function create($data) {
        $sql = "INSERT INTO categories (name, slug, description, image, status) VALUES (?, ?, ?, ?, ?)";
        $params = [
            $data['name'],
            $data['slug'],
            $data['description'] ?? null,
            $data['image'] ?? null,
            $data['status'] ?? 'active'
        ];
        
        try {
            $this->db->query($sql, $params);
            return $this->db->getConnection()->lastInsertId();
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                throw new Exception('Category with this slug already exists');
            }
            throw $e;
        }
    }
    
    public function update($id, $data) {
        $fields = [];
        $params = [];
        
        $updatableFields = ['name', 'slug', 'description', 'image', 'status'];
        
        foreach ($updatableFields as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $sql = "UPDATE categories SET " . implode(', ', $fields) . " WHERE id = ?";
        $params[] = $id;
        
        return $this->db->query($sql, $params);
    }
    
    public function delete($id) {
        // Check if category has products
        $hasProducts = $this->db->count('products', 'category_id = ?', [$id]) > 0;
        
        if ($hasProducts) {
            throw new Exception('Cannot delete category with associated products');
        }
        
        $sql = "DELETE FROM categories WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }
    
    public function findById($id) {
        $sql = "SELECT * FROM categories WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function findBySlug($slug) {
        $sql = "SELECT * FROM categories WHERE slug = ? AND status = 'active'";
        return $this->db->fetch($sql, [$slug]);
    }
    
    public function getAll($status = null) {
        $sql = "SELECT * FROM categories";
        $params = [];
        
        if ($status) {
            $sql .= " WHERE status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY name ASC";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function getAllActive() {
        return $this->getAll('active');
    }
    
    public function getWithProductCount() {
        $sql = "
            SELECT c.*, COUNT(p.id) as product_count
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id AND p.status = 'active'
            GROUP BY c.id
            ORDER BY c.name ASC
        ";
        return $this->db->fetchAll($sql);
    }
    
    public function getPopular($limit = 6) {
        $sql = "
            SELECT c.*, COUNT(p.id) as product_count
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id AND p.status = 'active'
            WHERE c.status = 'active'
            GROUP BY c.id
            HAVING product_count > 0
            ORDER BY product_count DESC, c.name ASC
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$limit]);
    }
    
    public function updateStatus($id, $status) {
        $sql = "UPDATE categories SET status = ? WHERE id = ?";
        return $this->db->query($sql, [$status, $id]);
    }
    
    public function count() {
        return $this->db->count('categories');
    }
    
    public function countActive() {
        return $this->db->count('categories', 'status = ?', ['active']);
    }
    
    public function search($query, $limit = 20) {
        $sql = "
            SELECT * FROM categories
            WHERE (name LIKE ? OR description LIKE ?)
            ORDER BY name ASC
            LIMIT ?
        ";
        $searchTerm = "%$query%";
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm, $limit]);
    }
    
    public function generateSlug($name, $id = null) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        $originalSlug = $slug;
        $counter = 1;
        
        while (true) {
            $sql = "SELECT id FROM categories WHERE slug = ?";
            $params = [$slug];
            
            if ($id) {
                $sql .= " AND id != ?";
                $params[] = $id;
            }
            
            $existing = $this->db->fetch($sql, $params);
            
            if (!$existing) {
                break;
            }
            
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }
    
    public function getStats() {
        $stats = [];
        
        // Total categories
        $stats['total'] = $this->count();
        
        // Active categories
        $stats['active'] = $this->countActive();
        
        // Inactive categories
        $stats['inactive'] = $this->db->count('categories', 'status = ?', ['inactive']);
        
        // Categories with products
        $result = $this->db->fetch("
            SELECT COUNT(DISTINCT category_id) as count 
            FROM products 
            WHERE status = 'active' AND category_id IS NOT NULL
        ");
        $stats['with_products'] = $result['count'] ?? 0;
        
        // Categories added this month
        $stats['this_month'] = $this->db->count(
            'categories',
            'created_at >= DATE_FORMAT(NOW(), "%Y-%m-01")'
        );
        
        return $stats;
    }
}
?>
