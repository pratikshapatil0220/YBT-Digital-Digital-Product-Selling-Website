<?php
require_once __DIR__ . '/../core/Database.php';

class User {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function create($data) {
        $sql = "INSERT INTO users (name, email, password_hash, phone, verification_token) VALUES (?, ?, ?, ?, ?)";
        $params = [
            $data['name'],
            $data['email'],
            $data['password_hash'],
            $data['phone'] ?? null,
            $data['verification_token'] ?? null
        ];
        
        try {
            $this->db->query($sql, $params);
            return $this->db->getConnection()->lastInsertId();
        } catch (Exception $e) {
            if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                throw new Exception('Email already exists');
            }
            throw $e;
        }
    }
    
    public function findByEmail($email) {
        $sql = "SELECT * FROM users WHERE email = ?";
        return $this->db->fetch($sql, [$email]);
    }
    
    public function findById($id) {
        $sql = "SELECT * FROM users WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }
    
    public function findByVerificationToken($token) {
        $sql = "SELECT * FROM users WHERE verification_token = ? AND email_verified = FALSE";
        return $this->db->fetch($sql, [$token]);
    }
    
    public function findByResetToken($token) {
        $sql = "SELECT * FROM users WHERE reset_token = ? AND reset_token_expiry > NOW()";
        return $this->db->fetch($sql, [$token]);
    }
    
    public function verifyEmail($userId) {
        $sql = "UPDATE users SET email_verified = TRUE, verification_token = NULL WHERE id = ?";
        return $this->db->query($sql, [$userId]);
    }
    
    public function setResetToken($userId, $token, $expiry) {
        $sql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?";
        return $this->db->query($sql, [$token, $expiry, $userId]);
    }
    
    public function resetPassword($userId, $passwordHash) {
        $sql = "UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?";
        return $this->db->query($sql, [$passwordHash, $userId]);
    }
    
    public function update($userId, $data) {
        $fields = [];
        $params = [];
        
        if (isset($data['name'])) {
            $fields[] = "name = ?";
            $params[] = $data['name'];
        }
        
        if (isset($data['phone'])) {
            $fields[] = "phone = ?";
            $params[] = $data['phone'];
        }
        
        if (isset($data['password_hash'])) {
            $fields[] = "password_hash = ?";
            $params[] = $data['password_hash'];
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
        $params[] = $userId;
        
        return $this->db->query($sql, $params);
    }
    
    public function updateStatus($userId, $status) {
        $sql = "UPDATE users SET status = ? WHERE id = ?";
        return $this->db->query($sql, [$status, $userId]);
    }
    
    public function getAll($limit = null, $offset = null) {
        $sql = "SELECT id, name, email, phone, status, email_verified, created_at FROM users ORDER BY created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT $limit";
            if ($offset) {
                $sql .= " OFFSET $offset";
            }
        }
        
        return $this->db->fetchAll($sql);
    }
    
    public function count() {
        return $this->db->count('users');
    }
    
    public function getPurchaseHistory($userId) {
        $sql = "
            SELECT o.*, oi.product_id, oi.product_title, oi.price, oi.quantity, p.thumbnail
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE o.user_id = ?
            ORDER BY o.created_at DESC
        ";
        return $this->db->fetchAll($sql, [$userId]);
    }
    
    public function getTotalSpent($userId) {
        $sql = "SELECT SUM(total_amount) as total FROM orders WHERE user_id = ? AND payment_status = 'completed'";
        $result = $this->db->fetch($sql, [$userId]);
        return $result['total'] ?? 0;
    }
    
    public function authenticate($email, $password) {
        $user = $this->findByEmail($email);
        
        if (!$user || $user['status'] !== 'active') {
            return false;
        }
        
        if (!password_verify($password, $user['password_hash'])) {
            return false;
        }
        
        // Remove sensitive data
        unset($user['password_hash']);
        unset($user['verification_token']);
        unset($user['reset_token']);
        
        return $user;
    }
    
    public function search($query, $limit = 20) {
        $sql = "
            SELECT id, name, email, phone, status, created_at
            FROM users
            WHERE name LIKE ? OR email LIKE ? OR phone LIKE ?
            ORDER BY created_at DESC
            LIMIT ?
        ";
        $searchTerm = "%$query%";
        return $this->db->fetchAll($sql, [$searchTerm, $searchTerm, $searchTerm, $limit]);
    }
    
    public function getRecentUsers($limit = 10) {
        $sql = "
            SELECT id, name, email, status, created_at
            FROM users
            ORDER BY created_at DESC
            LIMIT ?
        ";
        return $this->db->fetchAll($sql, [$limit]);
    }
    
    public function getStats() {
        $stats = [];
        
        // Total users
        $stats['total'] = $this->count();
        
        // Active users
        $stats['active'] = $this->db->count('users', 'status = ?', ['active']);
        
        // Blocked users
        $stats['blocked'] = $this->db->count('users', 'status = ?', ['blocked']);
        
        // Verified users
        $stats['verified'] = $this->db->count('users', 'email_verified = ?', [true]);
        
        // Users registered this month
        $stats['this_month'] = $this->db->count(
            'users',
            'created_at >= DATE_FORMAT(NOW(), "%Y-%m-01")'
        );
        
        // Users registered today
        $stats['today'] = $this->db->count(
            'users',
            'DATE(created_at) = CURDATE()'
        );
        
        return $stats;
    }
}
?>
