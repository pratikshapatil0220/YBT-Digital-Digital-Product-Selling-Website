<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'ybt_digital');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site Configuration
define('SITE_URL', 'http://localhost/YBT%20Digital/');
define('SITE_NAME', 'YBT Digital');
define('ADMIN_EMAIL', 'admin@ybt.digital');
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50MB

// Session Configuration
define('SESSION_LIFETIME', 7200); // 2 hours
define('COOKIE_SECURE', false);
define('COOKIE_HTTPONLY', true);

// Security
define('HASH_COST', 12);
define('TOKEN_LENGTH', 32);

// Pagination
define('ITEMS_PER_PAGE', 12);

// Download Settings
define('DOWNLOAD_EXPIRY_HOURS', 24);
define('MAX_DOWNLOAD_ATTEMPTS', 5);

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Start Session
session_start();

// Database Connection - Commented out since Database class handles its own connection
// try {
//     $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
// } catch(PDOException $e) {
//     die("Database connection failed: " . $e->getMessage());
// }

// Helper Functions
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function generateToken($length = TOKEN_LENGTH) {
    return bin2hex(random_bytes($length / 2));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['admin_id']);
}

function getCurrentUser() {
    if (isLoggedIn()) {
        $db = Database::getInstance();
        $stmt = $db->getConnection()->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }
    return null;
}

function getCurrentAdmin() {
    if (isAdmin()) {
        $db = Database::getInstance();
        $stmt = $db->getConnection()->prepare("SELECT * FROM admin_users WHERE id = ?");
        $stmt->execute([$_SESSION['admin_id']]);
        return $stmt->fetch();
    }
    return null;
}

function redirect($url) {
    header("Location: " . SITE_URL . $url);
    exit();
}

function flashMessage($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function getFlashMessages() {
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

function getSetting($key, $default = null) {
    $db = Database::getInstance();
    static $settings = null;
    
    if ($settings === null) {
        $stmt = $db->getConnection()->query("SELECT setting_key, setting_value FROM settings");
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
    
    return $settings[$key] ?? $default;
}

function formatPrice($amount, $currency = null) {
    $currency = $currency ?? getSetting('site_currency', 'USD');
    $symbols = [
        'USD' => '$',
        'EUR' => '€',
        'GBP' => '£',
        'INR' => '₹'
    ];
    $symbol = $symbols[$currency] ?? $currency;
    return $symbol . number_format($amount, 2);
}

function uploadFile($file, $directory = 'uploads/') {
    if (!isset($file['error']) || is_array($file['error'])) {
        throw new RuntimeException('Invalid file parameters.');
    }

    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new RuntimeException('File size exceeds limit.');
        default:
            throw new RuntimeException('Unknown upload error.');
    }

    if ($file['size'] > MAX_FILE_SIZE) {
        throw new RuntimeException('File size exceeds maximum limit.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $allowedTypes = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'pdf' => 'application/pdf',
        'zip' => 'application/zip',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!array_key_exists($ext, $allowedTypes) || $allowedTypes[$ext] !== $finfo->file($file['tmp_name'])) {
        throw new RuntimeException('Invalid file type.');
    }

    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }

    $filename = uniqid() . '.' . $ext;
    $filepath = $directory . $filename;

    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        throw new RuntimeException('Failed to move uploaded file.');
    }

    return $filepath;
}

function sendEmail($to, $subject, $message, $headers = []) {
    $defaultHeaders = [
        'From: ' . getSetting('email_from_name', SITE_NAME) . ' <' . getSetting('email_from', ADMIN_EMAIL) . '>',
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8'
    ];
    
    $headers = array_merge($defaultHeaders, $headers);
    
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

function logActivity($type, $message, $user_id = null) {
    $db = Database::getInstance();
    $stmt = $db->getConnection()->prepare("INSERT INTO activity_logs (type, message, user_id, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        $type,
        $message,
        $user_id,
        $_SERVER['REMOTE_ADDR'] ?? '',
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
}
?>
