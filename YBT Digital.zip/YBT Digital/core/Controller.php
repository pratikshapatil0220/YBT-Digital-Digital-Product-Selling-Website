<?php
require_once __DIR__ . '/Database.php';

abstract class Controller {
    protected $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    protected function render($view, $data = []) {
        extract($data);
        $flashMessages = getFlashMessages();
        
        $viewFile = 'views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require_once 'views/layouts/header.php';
            require_once $viewFile;
            require_once 'views/layouts/footer.php';
        } else {
            throw new Exception("View file not found: $viewFile");
        }
    }
    
    protected function renderAdmin($view, $data = []) {
        extract($data);
        $flashMessages = getFlashMessages();
        
        $viewFile = 'admin/views/' . $view . '.php';
        if (file_exists($viewFile)) {
            require_once 'admin/views/layouts/header.php';
            require_once $viewFile;
            require_once 'admin/views/layouts/footer.php';
        } else {
            throw new Exception("Admin view file not found: $viewFile");
        }
    }
    
    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
    
    protected function validateRequired($data, $fields) {
        $errors = [];
        foreach ($fields as $field) {
            if (empty($data[$field])) {
                $errors[$field] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
            }
        }
        return $errors;
    }
    
    protected function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    protected function validatePassword($password) {
        return strlen($password) >= 8;
    }
    
    protected function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitizeInput'], $data);
        }
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    
    protected function isPost() {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }
    
    protected function isGet() {
        return $_SERVER['REQUEST_METHOD'] === 'GET';
    }
    
    protected function getPost($key = null, $default = null) {
        if ($key === null) {
            return $this->sanitizeInput($_POST);
        }
        return $this->sanitizeInput($_POST[$key] ?? $default);
    }
    
    protected function getQuery($key = null, $default = null) {
        if ($key === null) {
            return $this->sanitizeInput($_GET);
        }
        return $this->sanitizeInput($_GET[$key] ?? $default);
    }
    
    protected function requireAuth() {
        if (!isLoggedIn()) {
            flashMessage('error', 'Please login to continue');
            redirect('auth/login');
        }
    }
    
    protected function requireAdminAuth() {
        if (!isAdmin()) {
            flashMessage('error', 'Admin access required');
            redirect('admin/login');
        }
    }
    
    protected function paginate($query, $params = [], $perPage = ITEMS_PER_PAGE) {
        $page = max(1, (int)($this->getQuery('page', 1)));
        $offset = ($page - 1) * $perPage;
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM ($query) as count_query";
        $total = $this->db->fetch($countQuery, $params)['total'];
        
        // Get paginated results
        $paginatedQuery = $query . " LIMIT $perPage OFFSET $offset";
        $items = $this->db->fetchAll($paginatedQuery, $params);
        
        return [
            'items' => $items,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => ceil($total / $perPage),
                'total_items' => $total,
                'per_page' => $perPage,
                'has_next' => $page < ceil($total / $perPage),
                'has_prev' => $page > 1
            ]
        ];
    }
    
    protected function generateSlug($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/', '-', $text);
        return trim($text, '-');
    }
    
    protected function uploadImage($file, $directory = 'uploads/images/') {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new Exception('Invalid file upload');
        }
        
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            throw new Exception('Invalid image type');
        }
        
        if ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
            throw new Exception('Image size too large');
        }
        
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $extension;
        $filepath = $directory . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new Exception('Failed to upload image');
        }
        
        return $filepath;
    }
}
?>
