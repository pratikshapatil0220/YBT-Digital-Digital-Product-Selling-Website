<?php
require_once 'config.php';

$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? '';

switch($page) {
    case 'home':
        require_once 'controllers/HomeController.php';
        $controller = new HomeController();
        $controller->index();
        break;
    case 'products':
        require_once 'controllers/ProductController.php';
        $controller = new ProductController();
        if ($action == 'detail') {
            $controller->detail($_GET['id'] ?? 0);
        } else {
            $controller->listing();
        }
        break;
    case 'auth':
        require_once 'controllers/AuthController.php';
        $controller = new AuthController();
        $controller->$action();
        break;
    case 'cart':
        require_once 'controllers/CartController.php';
        $controller = new CartController();
        $controller->$action();
        break;
    case 'checkout':
        require_once 'controllers/CheckoutController.php';
        $controller = new CheckoutController();
        $controller->$action();
        break;
    case 'orders':
        require_once 'controllers/OrderController.php';
        $controller = new OrderController();
        $controller->index();
        break;
    case 'download':
        require_once 'controllers/DownloadController.php';
        $controller = new DownloadController();
        $controller->download($_GET['token'] ?? '');
        break;
    case 'support':
        require_once 'controllers/SupportController.php';
        $controller = new SupportController();
        $controller->$action();
        break;
    case 'admin':
        require_once 'admin/index.php';
        break;
    default:
        http_response_code(404);
        require_once 'views/404.php';
        break;
}
?>
